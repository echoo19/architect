function run(args, ctx) {
  function s(v){ if(v===null||v===undefined) return ""; return String(v).trim(); }
  function sL(v){ return s(v).toLowerCase(); }
  function stripQuotes(t){ t=s(t); if(t.length>=2&&((t[0]==='"'&&t[t.length-1]==='"')||(t[0]==="'"&&t[t.length-1]==="'"))) return t.slice(1,-1).trim(); return t; }
  function normDate(v){
    let t=stripQuotes(v);
    if(!t) return "";
    let m=t.match(/^(\d{4}-\d{2}-\d{2})/);
    if(m) return m[1];
    let d=new Date(t);
    if(!isNaN(d)) return d.toISOString().slice(0,10);
    return t;
  }
  function toCents(v){ v=stripQuotes(v); if(v==="") return 0; var t=String(v).replace(/,/g,""); var m=t.match(/-?\d+(?:\.\d+)?/); if(!m) return 0; return Math.round(Number(m[0])*100); }
  const q=sL(args.query);
  const orders=ctx.readTable("orders.csv",{});
  const lines=ctx.readTable("order_lines.csv",{});
  const prods=ctx.readTable("products.csv",{});
  const custs=ctx.readTable("customers.csv",{});
  let cmap={};
  try{ const cm=ctx.readTable("category_map.csv",{}); for(const r of cm){ cmap[sL(r.legacy_code)]=sL(r.category); } }catch(e){}
  function targetCat(c){ const l=sL(c); if(cmap[l]) return cmap[l]; return l; }
  function prodCat(sku){
    const k=sL(sku);
    for(const r of prods){ if(sL(r.sku)===k) return sL(r.category); }
    return "";
  }
  function findCust(email){
    const k=sL(email);
    for(const r of custs){ if(sL(r.email)===k) return r; }
    return null;
  }
  if(q==="spending"){
    const email=s(args.customer_email); const since=normDate(args.since_date); const tc=targetCat(args.category);
    const c=findCust(email);
    if(!c) throw new Error("customer not found");
    const ck=s(c.customer_id);
    const oids={};
    for(const o of orders){ if(s(o.customer_id)===ck&&normDate(o.order_date)>=since) oids[s(o.order_id)]=true; }
    let sum=0;
    for(const l of lines){ if(oids[s(l.order_id)]&&prodCat(l.sku)===tc){ sum+=parseInt(s(l.qty),10)*toCents(l.unit_price); } }
    return {spent_cents:sum};
  }
  if(q==="sales"){
    const skuK=sL(args.sku); const m=s(args.month).slice(0,7);
    const yr=parseInt(m.slice(0,4),10), mo=parseInt(m.slice(5,7),10);
    const last=new Date(Date.UTC(yr,mo,0)).getUTCDate();
    const st=m+"-01", en=m+"-"+String(last).padStart(2,"0");
    const oids={};
    for(const o of orders){ const d=normDate(o.order_date); if(d>=st&&d<=en) oids[s(o.order_id)]=true; }
    let u=0,s2=0;
    for(const l of lines){ if(oids[s(l.order_id)]&&sL(l.sku)===skuK){ u+=parseInt(s(l.qty),10); s2+=parseInt(s(l.qty),10)*toCents(l.unit_price); } }
    return {units:u,sales_cents:s2};
  }
  if(q==="unshipped"){
    const regionK=sL(args.region); const dob=normDate(args.on_or_before);
    const ids={};
    for(const c of custs){ if(sL(c.region)===regionK) ids[s(c.customer_id)]=true; }
    let out=[];
    for(const o of orders){ if(ids[s(o.customer_id)]&&s(o.shipped_on)===""&&normDate(o.order_date)<=dob) out.push(s(o.order_id)); }
    out.sort(); return {order_ids:out};
  }
  if(q==="orders_total"){
    const email=s(args.customer_email); const m=s(args.month).slice(0,7);
    const yr=parseInt(m.slice(0,4),10), mo=parseInt(m.slice(5,7),10);
    const last=new Date(Date.UTC(yr,mo,0)).getUTCDate();
    const st=m+"-01", en=m+"-"+String(last).padStart(2,"0");
    const c=findCust(email);
    if(!c) throw new Error("customer not found");
    const ck=s(c.customer_id);
    let ol=[];
    for(const o of orders){ const d=normDate(o.order_date); if(s(o.customer_id)===ck&&d>=st&&d<=en) ol.push(o); }
    ol.sort((a,b)=>s(a.order_id)<s(b.order_id)?-1:1);
    const byId={};
    for(const l of lines){ const k=s(l.order_id); if(!byId[k]) byId[k]=[]; byId[k].push(l); }
    let total=0; const ids=[];
    for(const o of ol){ ids.push(s(o.order_id)); let t=toCents(o.shipping); const ls=byId[s(o.order_id)]||[]; for(const l of ls) t+=parseInt(s(l.qty),10)*toCents(l.unit_price); total+=t; }
    return {order_ids:ids,total_cents:total};
  }
  throw new Error("unknown query");
}

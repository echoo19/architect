function run(args, ctx) {
  const TODAY = "2026-11-24";
  function s(v){ if(v===null||v===undefined) return ""; return String(v).trim(); }
  function sL(v){ return s(v).toLowerCase(); }
  function stripQ(t){ t=s(t); if(t.length>=2&&((t[0]=='"'&&t[t.length-1]=='"')||(t[0]=="'"&&t[t.length-1]=="'"))) return t.slice(1,-1).trim(); return t; }
  function normDate(v){
    let t=stripQ(v);
    if(!t) return "";
    let m=t.match(/^(\d{4}-\d{2}-\d{2})/);
    if(m) return m[1];
    let d=new Date(t);
    if(!isNaN(d)) return d.toISOString().slice(0,10);
    return t;
  }
  function toCents(v){ v=stripQ(v); if(v==="") return 0; var t=String(v).replace(/,/g,""); var m=t.match(/-?\d+(?:\.\d+)?/); if(!m) return 0; return Math.round(Number(m[0])*100); }
  function daysBetween(a,b){ const ms=Date.parse(b+"T00:00:00Z")-Date.parse(a+"T00:00:00Z"); return Math.round(ms/86400000); }
  const orderId = s(args.order_id);
  const skuK = sL(args.sku); const skuRaw = s(args.sku);
  const qty = parseInt(s(args.qty),10);
  const cond = sL(args.condition);
  const req = s(args.request_id);
  const num = req.indexOf("-")>=0 ? s(req.split("-")[1]) : req;
  const returnId = "RT-"+num;
  const orders = ctx.readTable("orders.csv",{});
  const lines = ctx.readTable("order_lines.csv",{});
  const prods = ctx.readTable("products.csv",{});
  const custs = ctx.readTable("customers.csv",{});
  const rets = ctx.readTable("returns.csv",{});
  let order=null;
  for(const r of orders){ if(s(r.order_id)===orderId){ order=r; break; } }
  if(!order) throw new Error("order not found "+orderId);
  let line=null;
  for(const r of lines){ if(s(r.order_id)===orderId&&sL(r.sku)===skuK){ line=r; break; } }
  if(!line) throw new Error("line not found");
  let prod=null;
  for(const r of prods){ if(sL(r.sku)===skuK){ prod=r; break; } }
  if(!prod) throw new Error("product not found");
  let cust=null;
  const cid=s(order.customer_id);
  for(const r of custs){ if(s(r.customer_id)===cid){ cust=r; break; } }
  const memberSince = cust ? normDate(cust.member_since) : "";
  const orderDate = normDate(order.order_date);
  const memberPerks = memberSince!==""&&memberSince<=orderDate;
  let days = 9999;
  const del = normDate(order.delivered_on);
  if(del!=="") days = daysBetween(del, TODAY);
  const unitCents = toCents(line.unit_price);
  const item = qty*unitCents;
  const lineQty = parseInt(s(line.qty),10);
  let used=0;
  for(const r of rets){ if(s(r.order_id)===orderId&&sL(r.sku)===skuK&&sL(r.decision)==="approved") used+=parseInt(s(r.qty),10); }
  const left = lineQty-used;
  const limit = cond==="defective"?90:(memberPerks?60:30);
  let decision="approved";
  if(days>limit) decision="denied";
  if(sL(prod.final_sale)==="yes"&&cond!=="defective") decision="denied";
  if(!(qty<=left)) decision="denied";
  let restock=0, retShip=0, shipRef=0, refund=0, refundTo="none";
  if(decision==="approved"){
    const cat=sL(prod.category);
    if(cond==="opened"&&(cat==="tents"||cat==="sleeping"||cat==="electronics")) restock=Math.floor((item*15+50)/100);
    retShip=(memberPerks||cond==="defective")?0:695;
    if(cond==="defective"){
      let already=false;
      for(const r of rets){ if(s(r.order_id)===orderId&&sL(r.decision)==="approved"&&parseInt(s(r.shipping_refund_cents)||"0",10)!==0){already=true;break;} }
      if(!already) shipRef=toCents(order.shipping);
    }
    refund=item-restock-retShip+shipRef;
    const pay=sL(order.payment);
    refundTo=(pay==="card"&&days<=30)?"card":"store_credit";
  }
  const row=[returnId,orderId,skuRaw,String(qty),cond,TODAY,decision,String(item),String(restock),String(retShip),String(shipRef),String(refund),refundTo,""];
  return {return_id:returnId,order_id:orderId,sku:skuRaw,qty:qty,condition:cond,decided_on:TODAY,decision:decision,item_cents:item,restocking_fee_cents:restock,return_shipping_cents:retShip,shipping_refund_cents:shipRef,refund_cents:refund,refund_to:refundTo,pickup_from:"",csv_line:row.join(",")};
}

function run(args, ctx) {
  const TODAY="2026-11-24", CLOSED="2026-11-26";
  function s(v){ if(v===null||v===undefined) return ""; return String(v).trim(); }
  function sL(v){ return s(v).toLowerCase(); }
  function stripQ(t){ t=s(t); if(t.length>=2&&((t[0]=='"'&&t[t.length-1]=='"')||(t[0]=="'"&&t[t.length-1]=="'"))) return t.slice(1,-1).trim(); return t; }
  function normDate(v){
    let t=stripQ(v);
    if(!t) return "";
    let m=t.match(/^(\d{4}-\d{2}-\d{2})/);
    if(m) return m[1];
    let d=new Date(t);
    if(!isNaN(d)) return d.toISOString().slice(0,10);
    return t;
  }
  const rid=s(args.return_id); const bat=s(args.booked_at);
  const m=bat.match(/(\d{1,2}):(\d{2})/); if(!m) throw new Error("bad booked_at");
  const mins=parseInt(m[1],10)*60+parseInt(m[2],10);
  const first = mins<14*60 ? "2026-11-25" : "2026-11-26";
  const rets=ctx.readTable("returns.csv",{});
  const orders=ctx.readTable("orders.csv",{});
  const custs=ctx.readTable("customers.csv",{});
  const prods=ctx.readTable("products.csv",{});
  const picks=ctx.readTable("pickups.csv",{});
  let r=null;
  for(const x of rets){ if(s(x.return_id)===rid){ r=x; break; } }
  if(!r) throw new Error("return not found "+rid);
  const oid=s(r.order_id); const skuK=sL(r.sku);
  let o=null;
  for(const x of orders){ if(s(x.order_id)===oid){ o=x; break; } }
  if(!o) throw new Error("order not found");
  let c=null;
  const cid=s(o.customer_id);
  for(const x of custs){ if(s(x.customer_id)===cid){ c=x; break; } }
  let p=null;
  for(const x of prods){ if(sL(x.sku)===skuK){ p=x; break; } }
  const region=sL(c?s(c.region):""); const bulky=p?sL(p.bulky):"no";
  let carrier;
  if(bulky==="yes") carrier="Basalt Freight";
  else if(region==="lakeshore"||region==="valley") carrier="Cedarline Parcel";
  else carrier="Kettlepoint Courier";
  const daysMap={"Cedarline Parcel":[1,2,4,5],"Kettlepoint Courier":[1,3,5,6],"Basalt Freight":[2,4]};
  const allowed=daysMap[carrier];
  let pf=normDate(r.pickup_from);
  let start=first; if(pf!==""&&pf>start) start=pf;
  const counts={};
  for(const k of picks){ if(s(k.carrier)===carrier){ const d=normDate(k.pickup_date); if(d) counts[d]=(counts[d]||0)+1; } }
  function addDays(d,n){ const dt=new Date(d+"T00:00:00Z"); dt.setUTCDate(dt.getUTCDate()+n); return dt.toISOString().slice(0,10); }
  let d=start;
  for(let i=0;i<365;i++){
    if(d!==CLOSED){
      const wd=new Date(d+"T00:00:00Z").getUTCDay();
      if(allowed.indexOf(wd)>=0&&((counts[d]||0)<3)){ break; }
    }
    d=addDays(d,1);
  }
  const parts=rid.split("-"); const num=s(parts[1]||rid); const pid="PU-"+num;
  return {pickup_id:pid,return_id:rid,carrier:carrier,pickup_date:d,booked_on:TODAY,csv_line:[pid,rid,carrier,d,TODAY].join(",")};
}
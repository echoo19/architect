---
name: refund-return
description: Decide a return request RQ- and record it in returns.csv.
---
Refund request steps. Today is 2026-11-24.
1. Parse request: order_id, sku, qty, condition (unopened/opened/defective), request_id like RQ-5012.
2. Call tool `refund_calc` with {order_id, sku, qty, condition, request_id}. It reads orders, order_lines, customers, products, returns and returns decision, all cents, refund_to, return_id RT-xxxx and csv_line.
3. Verify tool output matches request ids. Do not recompute by hand.
4. Append csv_line to returns.csv with append (one line, 14 columns: return_id,order_id,sku,qty,condition,decided_on,decision,item_cents,restocking_fee_cents,return_shipping_cents,shipping_refund_cents,refund_cents,refund_to,pickup_from; last empty if denied or no carrier).
5. End with: ANSWER: {"decision": "<approved or denied>", "refund_cents": <int>, "refund_to": "<card|store_credit|none>"}
Rules tool applies: member perks if member_since <= order_date; days delivered_on->2026-11-24; on-time 30 / 60 member / 90 defective; final_sale yes only defective; enough left = line qty minus approved same order+sku; item=qty*unit_price; restock 15% half-up if opened and tents/sleeping/electronics; return shipping 695 unless member or defective; defective shipping refund unless already refunded; refund_to card only if paid card and days<=30; denied keeps item only.

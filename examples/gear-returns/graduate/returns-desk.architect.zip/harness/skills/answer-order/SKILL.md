---
name: answer-order
description: Answer spending, sales, unshipped, or order-total questions.
---
Order question steps. Today 2026-11-24.
1. Identify subtype:
   - spent/spending + email + category + since DATE -> query spending
   - units sold/sales + SKU + month -> query sales
   - unshipped + region + on-or-before DATE -> query unshipped
   - orders placed in MONTH + email + total -> query orders_total
2. Normalize: email as given; category lowercased (map legacy_code via category_map if needed - tool does it); month name to YYYY-MM (e.g. August 2026 -> 2026-08); dates YYYY-MM-DD.
3. Call tool `order_lookup`:
   - spending: {query:"spending", customer_email, category, since_date}
   - sales: {query:"sales", sku, month}
   - unshipped: {query:"unshipped", region, on_or_before}
   - orders_total: {query:"orders_total", customer_email, month}
4. Use tool result directly. Do not sum by eye. If needed verify with run + files.read.
5. End with exact shape asked:
   - ANSWER: {"spent_cents": N}
   - ANSWER: {"units": N, "sales_cents": N}
   - ANSWER: {"order_ids": ["...", ...]} (sorted)
   - ANSWER: {"order_ids": [...], "total_cents": N}
Definitions: spending = qty*unit_price on orders with order_date>=since, only lines of that category, no shipping, no return deduction. Sales counts orders by order_date in month. Total = lines + shipping. Unshipped = shipped_on empty and order_date<=date and customer region matches.

---
name: book-pickup
description: Book earliest carrier pickup for an approved return RT-.
---
Pickup steps. Today booked_on 2026-11-24.
1. Parse request: return_id like RT-4107, booked time HH:MM (e.g. 15:30). If text says 15:30 on Nov 24, booked_at is 15:30.
2. Call tool `pickup_plan` with {return_id, booked_at}. It reads returns->order->customer region, product bulky, pickups counts and returns carrier, pickup_date, pickup_id PU-xxxx, booked_on, csv_line.
3. Do not pick date by hand. Tool applies: bulky yes -> Basalt Freight else Lakeshore/Valley -> Cedarline Parcel else Foothills/Uplands -> Kettlepoint Courier; days Cedarline Mon Tue Thu Fri, Kettlepoint Mon Wed Fri Sat, Basalt Tue Thu; closed 2026-11-26; earliest tomorrow if booked before 14:00 else day-after-tomorrow, never before pickup_from; capacity max 3 per carrier per day.
4. Append csv_line to pickups.csv with append (5 columns: pickup_id,return_id,carrier,pickup_date,booked_on).
5. End with: ANSWER: {"pickup_id": "<id>", "carrier": "<carrier>", "pickup_date": "<YYYY-MM-DD>"}

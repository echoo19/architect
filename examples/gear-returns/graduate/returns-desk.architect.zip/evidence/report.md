# Returns desk: report card

**58 of 60 locked test tasks passed (96.7%).** The target was 95%, so the pass rate requirement was met.

- Student: Glimmer (meta/muse-glimmer-30b, a hosted copy)
- Mentor: Spark (muse-spark-1.3)
- Method: Architect
- Created: 2026-10-29

## Results by task type

| Task type | Passed | Total | Pass rate |
| --- | ---: | ---: | ---: |
| Refunds | 19 | 20 | 95% |
| Order questions | 19 | 20 | 95% |
| Pickups | 20 | 20 | 100% |
| All tasks | 58 | 60 | 96.7% |

## Speed

The median answer took 3.5 s. The slowest 5% took 4.8 s or longer.

## Training

- Rounds: 4
- Mentor cost: $0.34 (186,121 input tokens, 41,713 output tokens)
- Hosted student cost: $1.66, billed by the student's host
- Training time: 28 min
- Dev tasks passed: 68.9% at the start (31 of 45), 97.8% at the end (88 of 90)
- Dev pass rate 97.8%, locked test pass rate 96.7%: a gap of 1.1 points

## Refused task types

None. The graduate attempts every task type.

## What helped most

1. Round 1, "Normalize dirty values in helpers": +23 dev passes over 2 runs
2. Round 4, "Parse dirty money with numeric extraction in helpers": +4 dev passes over 2 runs

## Requirements

- Pass rate: target 95%, result 96.7%. Met.

## The mentor's readiness claim

During training the mentor said the student was ready, and the locked test agreed.

## How the test was run

The locked test was run once on a hosted copy of the student with the mentor disconnected, so it was not run offline. The mentor never saw these tasks.
